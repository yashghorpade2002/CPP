/*# include <iostream>

class Addtwo {

	private:
		int x = 10;
		int y = 20;

	public:
		
		friend int operator+(Addtwo& ref1, Addtwo& ref2);

};

int operator+(Addtwo& ref1, Addtwo& ref2) {

	return ref1.x + ref2.y;

}
int main() {

	Addtwo obj1;
	Addtwo obj2;

	std::cout << obj1 + obj2 <<std::endl;

	return 0;

}*/


