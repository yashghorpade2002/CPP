# include <iostream>

static int x = 10;
int y = 20;

void fun() ;

int main() {
  
	fun();


  return 0;
}
