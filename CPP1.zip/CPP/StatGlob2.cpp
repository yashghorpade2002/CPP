
# include <iostream>

void fun() {
  
	extern int y;
	std::cout<<y<<std::endl;

}
